#========[স্বয়ংক্রিয় ব্যাকআপ স্ক্রিপ্ট]========
import os
import io
import json
import datetime
import asyncio
from telegram import Bot, InputFile
from telegram.constants import ParseMode
from dotenv import load_dotenv

# These imports should point to your project's database module
from database import get_full_backup_data, get_stats, client

async def main():
    load_dotenv()
    bot_token = os.getenv("BOT_TOKEN")
    backup_channel_id = int(os.getenv("BACKUP_CHANNEL_ID"))
    # Notify the first admin in the list
    admin_user_id = int(os.getenv("ADMIN_USER_IDS").split(',')[0])

    if not bot_token or not backup_channel_id or not admin_user_id:
        print("Error: Required environment variables for backup are not set.")
        return

    bot = Bot(token=bot_token)
    
    try:
        print("Starting daily backup...")
        backup_data = get_full_backup_data()
        total_users, total_files, _ = get_stats()

        file_name = f"auto_backup_{datetime.datetime.now().strftime('%Y-%m-%d')}.json"
        json_file = io.BytesIO(json.dumps(backup_data, indent=4, ensure_ascii=False).encode('utf-8'))
        
        caption = (f"🤖 <b>দৈনিক স্বয়ংক্রিয় ব্যাকআপ</b>\n\n"
                   f"📅 তারিখ: {datetime.datetime.now().strftime('%d %B, %Y %I:%M %p')}\n"
                   f"👥 মোট ব্যবহারকারী: {total_users}\n"
                   f"📁 মোট ফাইল: {total_files}")
                   
        await bot.send_document(
            chat_id=backup_channel_id,
            document=InputFile(json_file, filename=file_name),
            caption=caption,
            parse_mode=ParseMode.HTML
        )
        await bot.send_message(admin_user_id, "✅ আজকের স্বয়ংক্রিয় ডেটাবেজ ব্যাকআপ সফলভাবে সম্পন্ন হয়েছে।")
        print("Backup successful.")

    except Exception as e:
        error_message = f"❌ আজকের স্বয়ংক্রিয় ডেটাবেজ ব্যাকআপ ব্যর্থ হয়েছে।\nত্রুটি: {e}"
        await bot.send_message(admin_user_id, text=error_message)
        print(error_message)
    finally:
        # Close the database connection
        client.close()

if __name__ == "__main__":
    # To run this script, use `python auto_backup.py`
    # You should set this up with a cron job to run daily.
    asyncio.run(main())
