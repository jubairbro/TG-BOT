#========[বটের মূল প্রবেশপথ]========
import logging
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ConversationHandler,
    filters,
    Defaults
)
from telegram.constants import ParseMode

import config
from handlers.user_handlers import start_command, help_command, my_files_command, callback_query_handler
from handlers.admin_handlers import stats_command, broadcast_command, backup_command
from handlers.conversation_handlers import (
    GET_CAPTION, ask_for_caption, receive_caption, skip_caption, cancel_upload
)

# Enable logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

def main() -> None:
    """Start the bot."""
    # Set default parse mode to HTML for all messages
    # 'disable_web_page_preview' has been removed for better compatibility
    defaults = Defaults(parse_mode=ParseMode.HTML)
    
    # Create the Application and pass it your bot's token.
    application = Application.builder().token(config.BOT_TOKEN).defaults(defaults).build()

    # Conversation handler for file uploads
    conv_handler = ConversationHandler(
        entry_points=[
            MessageHandler(filters.ALL & (filters.Document.ALL | filters.VIDEO | filters.PHOTO | filters.AUDIO) & (~filters.COMMAND), ask_for_caption)
        ],
        states={
            GET_CAPTION: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_caption),
                CommandHandler("skip", skip_caption),
            ]
        },
        fallbacks=[CommandHandler("cancel", cancel_upload)],
        allow_reentry=True,
    )

    # Add handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("myfiles", my_files_command))
    
    # Admin commands
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("broadcast", broadcast_command))
    application.add_handler(CommandHandler("backup", backup_command))

    # Add the conversation handler
    application.add_handler(conv_handler)

    # Handle all button clicks
    application.add_handler(CallbackQueryHandler(callback_query_handler))
    
    # Run the bot
    logger.info("Bot is starting...")
    application.run_polling(allowed_updates=['message', 'callback_query'])

if __name__ == "__main__":
    main()
