#========[ভাষা ব্যবস্থাপনা]========
import json
from pathlib import Path

# Load all translation files from the 'locales' directory
locales_dir = Path(__file__).parent.joinpath('locales')
translations = {}

try:
    for lang_file in locales_dir.glob('*.json'):
        lang_code = lang_file.stem
        with open(lang_file, 'r', encoding='utf-8') as f:
            translations[lang_code] = json.load(f)
except FileNotFoundError:
    print("Error: 'locales' directory not found. Please create it and add language files.")
    translations['en'] = {} # Fallback

def get_string(lang_code, key):
    # Fallback to English if the user's language is not found
    lang_data = translations.get(lang_code, translations.get('en', {}))
    # Fallback to the key itself if the string is not found
    return lang_data.get(key, key)
