#========[সহকারী ফাংশন ও ডেকোরেটর]========
from functools import wraps
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ChatMemberStatus
from telegram.error import BadRequest

import config
from language import get_string
from database import get_user_lang, is_user_verified, set_user_verified

# Decorator to restrict commands to admins
def admin_only(func):
    @wraps(func)
    async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        if user_id not in config.ADMIN_USER_IDS:
            lang = get_user_lang(user_id)
            await update.message.reply_text(get_string(lang, "admin_only_command"))
            return
        return await func(update, context, *args, **kwargs)
    return wrapped

# Decorator to check if the user has joined the required channel
def check_user_join(func):
    @wraps(func)
    async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        if not user or user.id in config.ADMIN_USER_IDS:
            return await func(update, context, *args, **kwargs)
            
        # If context.args exists, it means a deep link was used.
        # We must save it to user_data before the context is lost.
        if context.args:
            context.user_data['deep_link_file_id'] = context.args[0]

        if is_user_verified(user.id):
            return await func(update, context, *args, **kwargs)

        try:
            member = await context.bot.get_chat_member(chat_id=config.FORCE_JOIN_CHANNEL_ID, user_id=user.id)
            if member.status in [ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]:
                set_user_verified(user.id) # Mark as verified for 24 hours
                return await func(update, context, *args, **kwargs)
        except BadRequest:
             pass # User is not in the channel.
        except Exception as e:
            print(f"Unexpected error in check_user_join for user {user.id}: {e}")

        # If user is not verified, send the join message
        lang = get_user_lang(user.id)
        keyboard = [
            [InlineKeyboardButton(get_string(lang, "join_channel_button"), url=f"https://t.me/{config.FORCE_JOIN_CHANNEL_NAME.lstrip('@')}")],
            [InlineKeyboardButton(get_string(lang, "verify_join_button"), callback_data="verify_join")]
        ]
        text = get_string(lang, "force_join_message").format(channel_name=config.FORCE_JOIN_CHANNEL_NAME)
        
        target = update.callback_query or update
        if isinstance(target, Update) and target.message:
            await target.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        elif target.message:
            await target.message.delete()
            await context.bot.send_message(user.id, text, reply_markup=InlineKeyboardMarkup(keyboard))

    return wrapped
