#========[কনভারসেশন হ্যান্ডলার]========
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from telegram.constants import ParseMode

import config
import database as db
from language import get_string
from utils import check_user_join

# States for ConversationHandler
GET_CAPTION = range(1)

def get_file_object_and_type(message):
    if message.document: return message.document, 'document'
    if message.video: return message.video, 'video'
    if message.photo: return message.photo[-1], 'photo'
    if message.audio: return message.audio, 'audio'
    return None, None

@check_user_join
async def ask_for_caption(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Entry point for the conversation. Asks for a caption."""
    lang = db.get_user_lang(update.effective_user.id)
    context.user_data['file_message'] = update.message
    await update.message.reply_text(text=get_string(lang, "request_caption"))
    return GET_CAPTION

async def process_file_with_caption(update: Update, context: ContextTypes.DEFAULT_TYPE, user_caption: str):
    """Helper function to save file, log user info, and send a reply with a button."""
    lang = db.get_user_lang(update.effective_user.id)
    original_message = context.user_data.get('file_message')
    if not original_message:
        return ConversationHandler.END

    user = original_message.from_user
    file_obj, file_type = get_file_object_and_type(original_message)
    file_name = getattr(file_obj, 'file_name', 'N/A')
    
    try:
        # 1. Prepare log for storage channel caption
        user_info_log = (f"👤 <b>Uploaded by:</b> <a href='tg://user?id={user.id}'>{user.full_name}</a>\n"
                         f"🆔 <b>User ID:</b> <code>{user.id}</code>\n"
                         f"🔤 <b>Username:</b> @{user.username if user.username else 'N/A'}\n"
                         "------------------------------------")
        
        # Final caption for the storage channel includes the log and the user's caption
        final_caption_for_storage = f"{user_info_log}\n\n{user_caption or ''}"

        # 2. Copy file to storage channel with the detailed caption
        sent_msg = await context.bot.copy_message(
            chat_id=config.FILE_SAVE_CHANNEL,
            from_chat_id=user.id,
            message_id=original_message.message_id,
            caption=final_caption_for_storage,
            parse_mode=ParseMode.HTML
        )

        # 3. Save file metadata to the database (only with the user-provided caption)
        file_id = db.save_file(sent_msg.message_id, user.id, file_type, file_name, user_caption)
        
        # 4. Create a deep link and a button for the user
        link = f"https://t.me/{config.BOT_USERNAME}?start={file_id}"
        keyboard = [[InlineKeyboardButton(get_string(lang, 'download_link_text'), url=link)]]
        
        await update.message.reply_text(
            text=get_string(lang, 'file_saved'),
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    except Exception as e:
        await update.message.reply_text(get_string(lang, "error_saving_file"))
        print(f"File saving error for user {user.id}: {e}")
    
    context.user_data.clear()
    return ConversationHandler.END

async def receive_caption(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Receives and saves the user-provided caption."""
    # use .text_html to preserve user's formatting (bold, italic, etc.)
    return await process_file_with_caption(update, context, update.message.text_html)

async def skip_caption(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Skips providing a new caption and uses the original one (if any)."""
    lang = db.get_user_lang(update.effective_user.id)
    original_message = context.user_data.get('file_message')
    
    await update.message.reply_text(get_string(lang, 'caption_skipped'))
    # Use the original message's caption, which might be None
    return await process_file_with_caption(update, context, original_message.caption_html)

async def cancel_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancels the file upload process."""
    lang = db.get_user_lang(update.effective_user.id)
    await update.message.reply_text(get_string(lang, 'file_upload_cancelled'))
    context.user_data.clear()
    return ConversationHandler.END
