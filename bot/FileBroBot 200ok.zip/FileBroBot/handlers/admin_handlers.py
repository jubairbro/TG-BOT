#========[অ্যাডমিন কমান্ড হ্যান্ডলার]========
import io
import json
import asyncio
import datetime
from telegram import Update, InputFile
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from telegram.error import BadRequest, Forbidden

import database as db
from language import get_string
from utils import admin_only
import config

@admin_only
async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = db.get_user_lang(update.effective_user.id)
    total_users, total_files, today_files = db.get_stats()
    text = get_string(lang, "stats_message").format(
        total_users=total_users,
        total_files=total_files,
        today_files=today_files
    )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)

@admin_only
async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg_to_broadcast = update.message.reply_to_message
    lang = db.get_user_lang(update.effective_user.id)

    if not msg_to_broadcast:
        await update.message.reply_text("Please reply to a message to start broadcasting.")
        return

    user_ids = db.get_all_user_ids()
    await update.message.reply_text(get_string(lang, "broadcast_start").format(user_count=len(user_ids)))

    success_count = 0
    failed_count = 0
    for user_id in user_ids:
        try:
            await context.bot.copy_message(
                chat_id=user_id,
                from_chat_id=msg_to_broadcast.chat_id,
                message_id=msg_to_broadcast.message_id
            )
            success_count += 1
        except (BadRequest, Forbidden) as e:
            failed_count += 1
            print(f"Broadcast failed for user {user_id}: {e}")
        await asyncio.sleep(0.1) # Avoid hitting API limits

    await update.message.reply_text(
        get_string(lang, "broadcast_complete").format(success_count=success_count, failed_count=failed_count)
    )

@admin_only
async def backup_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = db.get_user_lang(update.effective_user.id)
    await update.message.reply_text(get_string(lang, "backup_started"))
    try:
        backup_data = db.get_full_backup_data()
        json_str = json.dumps(backup_data, indent=4, ensure_ascii=False)
        json_file = io.BytesIO(json_str.encode('utf-8'))
        file_name = f"manual_backup_{datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.json"
        
        await context.bot.send_document(
            chat_id=update.effective_chat.id,
            document=InputFile(json_file, filename=file_name),
            caption=get_string(lang, "backup_success")
        )
    except Exception as e:
        await update.message.reply_text(f"Backup failed: {e}")
        print(f"Manual backup error: {e}")
