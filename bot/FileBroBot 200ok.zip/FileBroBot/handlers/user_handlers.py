#========[ব্যবহারকারীদের কমান্ড হ্যান্ডলার]========
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.error import BadRequest, Forbidden
from telegram.constants import ParseMode

import config
import database as db
from language import get_string
from utils import check_user_join

async def delete_message_job(context: ContextTypes.DEFAULT_TYPE):
    """Deletes the message specified in the job context."""
    job_data = context.job.data
    try:
        await context.bot.delete_message(chat_id=job_data['chat_id'], message_id=job_data['message_id'])
    except (BadRequest, Forbidden):
        pass # Ignore if the message is already deleted or bot is blocked

async def _send_file_from_deep_link(context: ContextTypes.DEFAULT_TYPE, user_id: int, file_id: str):
    """A dedicated helper function to find and send a file using its ID."""
    lang = db.get_user_lang(user_id)
    file_data = db.get_file_by_id(file_id)
    if not file_data:
        await context.bot.send_message(user_id, get_string(lang, 'file_not_found'))
        return

    try:
        # **BUG FIX**: copy_message returns a MessageId object, not a full Message object.
        # We cannot call .reply_text() on it. We must send a separate message.
        sent_msg_id_obj = await context.bot.copy_message(
            chat_id=user_id,
            from_chat_id=config.FILE_SAVE_CHANNEL,
            message_id=file_data['message_id'],
            caption=file_data.get('caption', ''),
            parse_mode=ParseMode.HTML
        )
        
        # Schedule the deletion of the sent file
        context.job_queue.run_once(
            delete_message_job, 
            3600, # 60 minutes
            data={'chat_id': user_id, 'message_id': sent_msg_id_obj.message_id},
            name=f"del_{user_id}_{sent_msg_id_obj.message_id}"
        )
        
        # Send the auto-deletion warning as a new message
        await context.bot.send_message(user_id, text=get_string(lang, 'auto_delete_alert'))
    except Exception as e:
        await context.bot.send_message(user_id, get_string(lang, 'file_not_found'))
        print(f"CRITICAL: Error in _send_file_from_deep_link for user {user_id}: {e}")

@check_user_join
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.add_user(user.id)

    # The decorator handles saving the deep link arg. Now, we retrieve it.
    file_id = context.user_data.pop('deep_link_file_id', None)
    if not file_id and context.args:
        file_id = context.args[0]

    if file_id:
        await _send_file_from_deep_link(context, user.id, file_id)
        return

    # If no deep link, show the standard welcome message
    keyboard = [
        [InlineKeyboardButton("🇬🇧 English", callback_data="set_lang:en"),
         InlineKeyboardButton("🇧🇩 বাংলা", callback_data="set_lang:bn")]
    ]
    await update.message.reply_text(
        text=get_string('en', 'welcome_select_language'),
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

@check_user_join
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = db.get_user_lang(update.effective_user.id)
    await update.message.reply_text(text=get_string(lang, "help_message"), disable_web_page_preview=True)

@check_user_join
async def my_files_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    lang = db.get_user_lang(user_id)
    files = db.get_user_files(user_id)
    if not files:
        await update.message.reply_text(get_string(lang, "no_files_found"))
        return
    text = get_string(lang, "my_files_header") + "\n\n"
    for file in files:
        file_name = file.get('file_name', 'Untitled')
        deep_link = f"https://t.me/{config.BOT_USERNAME}?start={file['file_id']}"
        download_link_text = get_string(lang, 'download_link_text')
        text += f"📄 <b>{file_name}</b>\n➡️ <a href='{deep_link}'>{download_link_text}</a>\n\n"
    await update.message.reply_text(text, disable_web_page_preview=True)

async def callback_query_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user
    data = query.data

    if data.startswith("set_lang:"):
        lang_code = data.split(":")[1]
        db.update_user_lang(user.id, lang_code)
        try:
            await query.message.edit_text(text=get_string(lang_code, "language_selected"))
        except BadRequest: # Message might be deleted
            pass
    
    elif data == "verify_join":
        lang = db.get_user_lang(user.id)
        # **BUG FIX**: Add a try-except block to prevent crashes on multiple clicks
        try:
            await query.message.delete()
        except BadRequest:
            pass # Message was already deleted, do nothing.

        # Explicitly check user's membership status NOW.
        try:
            member = await context.bot.get_chat_member(chat_id=config.FORCE_JOIN_CHANNEL_ID, user_id=user.id)
            if member.status not in ['creator', 'administrator', 'member']:
                raise Exception("User is not a member.") # Trigger the except block
            
            # If member, verify them and proceed
            db.set_user_verified(user.id)
            
            file_id = context.user_data.pop('deep_link_file_id', None)
            if file_id:
                await _send_file_from_deep_link(context, user.id, file_id)
            else:
                # If they just verified without a deep link, send a success message
                await context.bot.send_message(user.id, "✅ ধন্যবাদ! আপনাকে সফলভাবে যাচাই করা হয়েছে। এখন আপনি বট ব্যবহার করতে পারেন। বিস্তারিত জানতে /help কমান্ড দিন।")

        except Exception:
            # If they are still not a member, inform them.
            keyboard = [
                [InlineKeyboardButton(get_string(lang, "join_channel_button"), url=f"https://t.me/{config.FORCE_JOIN_CHANNEL_NAME.lstrip('@')}")],
                [InlineKeyboardButton(get_string(lang, "verify_join_button"), callback_data="verify_join")]
            ]
            await context.bot.send_message(user.id,
                text=f"❌ আপনি এখনও চ্যানেলে যোগ দেননি। অনুগ্রহ করে যোগ দিয়ে আবার চেষ্টা করুন।\n\n👉 {config.FORCE_JOIN_CHANNEL_NAME}",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
