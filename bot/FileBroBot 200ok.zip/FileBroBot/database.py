#========[ডেটাবেজ ব্যবস্থাপনা]========
import pymongo
import datetime
import shortuuid
from config import MONGO_URI, DB_NAME, BOT_USERNAME, EXPECTED_BACKUP_SIGNATURE

try:
    client = pymongo.MongoClient(MONGO_URI)
    db = client[DB_NAME]
    users_collection = db["users"]
    files_collection = db["files"]
except pymongo.errors.ConfigurationError as e:
    print(f"MongoDB Configuration Error: {e}")
    exit(1)


def add_user(user_id):
    if not users_collection.find_one({"user_id": user_id}):
        users_collection.insert_one({
            "user_id": user_id,
            "lang": "en",
            "join_date": datetime.datetime.utcnow(),
            "is_verified": False,
            "verified_until": None
        })

def get_user(user_id):
    return users_collection.find_one({"user_id": user_id})

def get_user_lang(user_id):
    user = get_user(user_id)
    return user.get("lang", "en") if user else "en"

def update_user_lang(user_id, lang_code):
    users_collection.update_one({"user_id": user_id}, {"$set": {"lang": lang_code}}, upsert=True)

def set_user_verified(user_id, hours=24):
    verified_until = datetime.datetime.utcnow() + datetime.timedelta(hours=hours)
    users_collection.update_one(
        {"user_id": user_id},
        {"$set": {"is_verified": True, "verified_until": verified_until}},
        upsert=True
    )

def is_user_verified(user_id):
    user = get_user(user_id)
    if not user:
        return False
    if user.get("is_verified") and user.get("verified_until") > datetime.datetime.utcnow():
        return True
    return False

def get_all_user_ids():
    return [user["user_id"] for user in users_collection.find({}, {"user_id": 1})]

def save_file(message_id, user_id, file_type, file_name, caption):
    file_id = shortuuid.uuid()
    files_collection.insert_one({
        "file_id": file_id,
        "message_id": message_id,
        "user_id": user_id,
        "file_type": file_type,
        "file_name": file_name,
        "caption": caption,
        "upload_date": datetime.datetime.utcnow()
    })
    return file_id

def get_file_by_id(file_id):
    return files_collection.find_one({"file_id": file_id})

def get_user_files(user_id, limit=10):
    return list(files_collection.find({"user_id": user_id}).sort("upload_date", pymongo.DESCENDING).limit(limit))

def get_stats():
    total_users = users_collection.count_documents({})
    total_files = files_collection.count_documents({})
    today_start = datetime.datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    today_files = files_collection.count_documents({"upload_date": {"$gte": today_start}})
    return total_users, total_files, today_files

def get_full_backup_data():
    def serialize_document(doc):
        doc['_id'] = str(doc['_id'])
        for key, value in doc.items():
            if isinstance(value, datetime.datetime):
                doc[key] = value.isoformat()
        return doc

    users_data = [serialize_document(user) for user in users_collection.find({})]
    files_data = [serialize_document(file) for file in files_collection.find({})]

    return {
        "backup_metadata": {
            "signature": EXPECTED_BACKUP_SIGNATURE,
            "bot_username": BOT_USERNAME,
            "creation_date_utc": datetime.datetime.utcnow().isoformat()
        },
        "data": {
            "users": users_data,
            "files": files_data
        }
    }
