#========[ডেটাবেজ রিস্টোর স্ক্রিপ্ট]========
import json
import os
import pymongo
from datetime import datetime
from dotenv import load_dotenv

def restore_database():
    load_dotenv()
    mongo_uri = os.getenv("MONGO_URI")
    db_name = os.getenv("DB_NAME")
    bot_username = os.getenv("BOT_USERNAME")
    expected_signature = "FILEBRO_BOT_BACKUP_V2.0" # Make sure this matches config

    # Connect to MongoDB
    try:
        client = pymongo.MongoClient(mongo_uri)
        db = client[db_name]
        users_collection, files_collection = db["users"], db["files"]
        print("✅ ডেটাবেজের সাথে সফলভাবে সংযোগ স্থাপন হয়েছে।")
    except Exception as e:
        print(f"❌ ডেটাবেজ সংযোগে ত্রুটি: {e}"), exit()

    path = input("👉 অনুগ্রহ করে আপনার ব্যাকআপ JSON ফাইলের পাথ দিন: ")
    if not os.path.exists(path):
        print(f"❌ ফাইল খুঁজে পাওয়া যায়নি: {path}"), exit()

    with open(path, 'r', encoding='utf-8') as f:
        backup_data = json.load(f)
    
    # Verification
    metadata = backup_data.get("backup_metadata", {})
    if metadata.get("signature") != expected_signature or metadata.get("bot_username") != bot_username:
        print("\n❌❌❌ ভেরিফিকেশন ব্যর্থ! এটি একটি অবৈধ বা বেমানান ব্যাকআপ ফাইল।"), exit()
    print(f"\n✅ ভেরিফিকেশন সফল! (Signature: {metadata.get('signature')})")
    print(f"🗓️ ব্যাকআপ তৈরির তারিখ: {metadata.get('creation_date_utc')}")

    # Final confirmation
    if input("\n⚠️ চূড়ান্ত সতর্কবার্তা! এই কাজটি বর্তমান ডেটাবেজের সমস্ত ডেটা মুছে ফেলবে। \nনিশ্চিত করতে 'YES I AM SURE' টাইপ করুন: ") != "YES I AM SURE":
        print("❌ রিস্টোর বাতিল করা হয়েছে।"), exit()
        
    try:
        print("\n⏳ বর্তমান ডেটাবেজ পরিষ্কার করা হচ্ছে...")
        users_collection.drop()
        files_collection.drop()
        print("✅ ডেটাবেজ পরিষ্কার সম্পন্ন।")

        users_data = backup_data.get("data", {}).get("users", [])
        files_data = backup_data.get("data", {}).get("files", [])
        
        # Helper to convert ISO date strings back to datetime objects
        def convert_dates(item_list):
            for item in item_list:
                for key, val in item.items():
                    if 'date' in key and isinstance(val, str):
                        try:
                            item[key] = datetime.fromisoformat(val)
                        except (ValueError, TypeError):
                            pass
            return item_list

        users_data = convert_dates(users_data)
        files_data = convert_dates(files_data)

        print(f"⏳ {len(users_data)} জন ব্যবহারকারী এবং {len(files_data)} টি ফাইল রিস্টোর করা হচ্ছে...")
        if users_data: users_collection.insert_many(users_data)
        if files_data: files_collection.insert_many(files_data)
        
        print("\n🚀 ✅ রিস্টোর প্রক্রিয়া সফলভাবে সম্পন্ন হয়েছে!")
    except Exception as e:
        print(f"❌ রিস্টোর করার সময় একটি অপ্রত্যাশিত ত্রুটি ঘটেছে: {e}")
    finally:
        client.close()

if __name__ == "__main__":
    restore_database()
