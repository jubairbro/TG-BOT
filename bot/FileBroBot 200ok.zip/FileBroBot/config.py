#========[কনফিগারেশন লোডার]========
import os
from dotenv import load_dotenv

load_dotenv()

# Helper function to read a comma-separated list of integers from .env
def get_list_from_env(key):
    value = os.getenv(key)
    return [int(x.strip()) for x in value.split(',')] if value else []

# Load all configurations
BOT_TOKEN = os.getenv("BOT_TOKEN")
BOT_USERNAME = os.getenv("BOT_USERNAME", "FileBroBot")

ADMIN_USER_IDS = get_list_from_env("ADMIN_USER_IDS")

FILE_SAVE_CHANNEL = int(os.getenv("FILE_SAVE_CHANNEL"))
FORCE_JOIN_CHANNEL_ID = int(os.getenv("FORCE_JOIN_CHANNEL_ID"))
FORCE_JOIN_CHANNEL_NAME = os.getenv("FORCE_JOIN_CHANNEL_NAME")
BACKUP_CHANNEL_ID = int(os.getenv("BACKUP_CHANNEL_ID"))

MONGO_URI = os.getenv("MONGO_URI")
DB_NAME = os.getenv("DB_NAME")

MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", "2147483648")) # Default 2GB

# Bot constants
EXPECTED_BACKUP_SIGNATURE = "FILEBRO_BOT_BACKUP_V2.0"

# Verify that essential configurations are set
if not all([BOT_TOKEN, BOT_USERNAME, ADMIN_USER_IDS, FILE_SAVE_CHANNEL, FORCE_JOIN_CHANNEL_ID, MONGO_URI, DB_NAME]):
    raise ValueError("One or more essential environment variables are not set. Please check your .env file.")
